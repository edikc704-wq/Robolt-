# Roblox Support Prank Chat — Setup Guide

> ⚠️ **PRANK WEBSITE** — Bukan afiliasi Roblox Corporation. Hanya untuk iseng-isengan!

---

## 1. Buat Firebase Project

1. Buka [https://console.firebase.google.com](https://console.firebase.google.com)
2. Klik **Add project** → beri nama proyek (bebas)
3. Aktifkan **Realtime Database**:
   - Build → Realtime Database → Create Database
   - Pilih region terdekat → **Start in test mode** (sementara)
4. Aktifkan **Storage**:
   - Build → Storage → Get Started → Start in test mode

---

## 2. Isi Firebase Config

Buka file **`js/firebase-config.js`** dan isi dengan konfigurasi Firebase kamu:

```js
const firebaseConfig = {
  apiKey:            "AIzaSy...",
  authDomain:        "nama-proyek.firebaseapp.com",
  databaseURL:       "https://nama-proyek-default-rtdb.firebaseio.com",
  projectId:         "nama-proyek",
  storageBucket:     "nama-proyek.appspot.com",
  messagingSenderId: "123456789",
  appId:             "1:123456789:web:abcdef123456"
};
```

Config ini ada di: Firebase Console → Project Settings → Your apps → Web app.

---

## 3. Firebase Security Rules (Penting!)

### Realtime Database Rules:
```json
{
  "rules": {
    ".read":  true,
    ".write": true
  }
}
```
> Untuk produksi, perketat rules ini sesuai kebutuhan.

### Storage Rules:
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if true;
    }
  }
}
```

---

## 4. Deploy ke Vercel

### Option A — Via Vercel Dashboard (Mudah):
1. Upload folder ini ke GitHub (drag & drop ke repo baru)
2. Buka [https://vercel.com](https://vercel.com) → New Project → Import repo
3. Klik **Deploy** → selesai!

### Option B — Via Vercel CLI:
```bash
npm i -g vercel
cd roblox-support
vercel
```

---

## 5. Cara Pakai

### User biasa:
- Buka website → masukkan username Roblox → **Start Chat**
- Chat langsung dengan "Support Roblox" secara real-time
- Bisa kirim teks, foto, video, file

### Owner (kamu):
- Masukkan username: **EDXZVIP**
- Masukkan PIN: **1942**
- Lihat semua user yang chat di dashboard
- Klik user → balas pesan secara real-time
- Settings: ganti nama/foto profil, clear chat user tertentu

---

## Struktur File

```
roblox-support/
├── index.html          ← Landing page (username input)
├── chat.html           ← User chat page
├── owner.html          ← Owner dashboard + settings
├── owner-chat.html     ← Owner reply to specific user
├── css/style.css       ← All styles
├── js/
│   ├── firebase-config.js  ← ← ← ISI INI DULU!
│   ├── index.js
│   ├── chat.js
│   ├── owner.js
│   └── owner-chat.js
└── vercel.json         ← Vercel config
```
