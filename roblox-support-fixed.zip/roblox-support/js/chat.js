/* ============================================================
   chat.js — User chat page logic (real-time via Firebase)
   ============================================================ */

(function () {
  'use strict';

  /* ── Auth guard ───────────────────────────────── */
  var username = localStorage.getItem('rb_username');
  var isOwner  = localStorage.getItem('rb_is_owner');
  if (!username || isOwner === '1') {
    window.location.replace('index.html');
    return;
  }

  /* ── DOM refs ─────────────────────────────────── */
  var messagesArea   = document.getElementById('messages-area');
  var chatSpinner    = document.getElementById('chat-spinner');
  var msgInput       = document.getElementById('msg-input');
  var btnSend        = document.getElementById('btn-send');
  var btnAttach      = document.getElementById('btn-attach');
  var fileInput      = document.getElementById('file-input');
  var uploadProgress = document.getElementById('upload-progress');
  var uploadLabel    = document.getElementById('upload-label');
  var progressFill   = document.getElementById('progress-fill');
  var uploadPct      = document.getElementById('upload-pct');
  var btnLogout      = document.getElementById('btn-logout');
  var modalLogout    = document.getElementById('modal-logout');
  var btnLogoutNo    = document.getElementById('btn-logout-no');
  var btnLogoutYes   = document.getElementById('btn-logout-yes');
  var hdrName        = document.getElementById('hdr-name');
  var hdrAvatar      = document.getElementById('hdr-avatar');
  var lightbox       = document.getElementById('lightbox');
  var lightboxImg    = document.getElementById('lightbox-img');
  var lightboxClose  = document.getElementById('lightbox-close');

  /* ── Firebase refs ────────────────────────────── */
  var messagesRef = db.ref('chats/' + username + '/messages');
  var ownerRef    = db.ref('owner/profile');
  var userRef     = db.ref('users/' + username);

  /* ── State ────────────────────────────────────── */
  var ownerProfile   = { name: 'Support Roblox', photoURL: '' };
  var messageListener = null;
  var initialLoad    = true;
  var _lastDateSep   = '';

  /* ── Notifications ────────────────────────────── */
  var NOTIF_ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Crect width='36' height='36' rx='6' fill='%23E53935'/%3E%3Cpath d='M10 8h11a7 7 0 0 1 0 20H16v8H6V4z' fill='%23fff'/%3E%3C/svg%3E";

  function requestNotificationPermission() {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'default') {
      Notification.requestPermission().catch(function() {});
    }
  }

  function showNotification(title, body, tag) {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    if (!document.hidden) return;
    try {
      var n = new Notification(title, {
        body: String(body || '').substring(0, 120),
        icon: NOTIF_ICON,
        tag:  tag || 'rb-chat',
        silent: false
      });
      n.onclick = function() { window.focus(); n.close(); };
      setTimeout(function() { n.close(); }, 6000);
    } catch (e) {}
  }

  /* ── Init ─────────────────────────────────────── */
  function init() {
    requestNotificationPermission();
    loadOwnerProfile();
    listenMessages();
    setupInput();
    setupLogout();
    setupLightbox();
    userRef.update({ lastSeen: firebase.database.ServerValue.TIMESTAMP }).catch(function() {});
  }

  /* ── Owner Profile ────────────────────────────── */
  function loadOwnerProfile() {
    ownerRef.on('value', function(snap) {
      var data = snap.val();
      if (data) {
        ownerProfile.name     = data.name     || 'Support Roblox';
        ownerProfile.photoURL = data.photoURL || '';
      }
      updateHeader();
    });
  }

  function updateHeader() {
    hdrName.textContent = ownerProfile.name;
    if (ownerProfile.photoURL) {
      hdrAvatar.innerHTML = '<img src="' + ownerProfile.photoURL + '" alt="Support" style="width:100%;height:100%;object-fit:cover;" />';
    } else {
      hdrAvatar.innerHTML = '<svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:22px;height:22px;"><path d="M6 4h14a10 10 0 0 1 0 20H16v8H6V4z" fill="#E53935"/><path d="M16 12v8h4a4 4 0 0 0 0-8h-4z" fill="#fff"/></svg>';
    }
  }

  /* ── Messages ─────────────────────────────────── */
  function listenMessages() {
    chatSpinner.style.display = 'block';

    var query = messagesRef.orderByChild('timestamp');
    messageListener = query;

    /* value: fires once after all existing child_added events.
       Used to do the full initial render (or welcome if empty). */
    query.on('value', function(snap) {
      if (!initialLoad) return;
      initialLoad = false;
      chatSpinner.style.display = 'none';
      messagesArea.innerHTML = '';
      _lastDateSep = '';

      if (!snap.exists()) {
        renderWelcome();
        return;
      }
      snap.forEach(function(child) {
        var msg = child.val();
        if (msg) appendMessage(msg);
      });
      scrollToBottom();
    });

    /* child_added: fires for existing children (skipped while initialLoad=true),
       then fires for every new message going forward. */
    query.on('child_added', function(snap) {
      if (initialLoad) return; // handled by value above
      var msg = snap.val();
      if (!msg) return;
      appendMessage(msg);
      // Push notification for owner's new messages
      if (msg.sender === 'owner') {
        showNotification(
          ownerProfile.name || 'Support Roblox',
          msg.type === 'image' ? '📷 Sent a photo' :
          msg.type === 'video' ? '🎥 Sent a video' :
          msg.type === 'file'  ? ('📎 ' + (msg.fileName || 'File')) :
          (msg.content || 'New message'),
          'owner-reply'
        );
      }
    });
  }

  function renderWelcome() {
    messagesArea.appendChild(makeDateSep('Today'));
    var welcomeMsg = {
      id:          'welcome',
      sender:      'owner',
      senderName:  ownerProfile.name,
      senderPhoto: ownerProfile.photoURL,
      type:        'text',
      content:     'Hello! Welcome to Roblox Support 👋 How can I help you today?',
      timestamp:   Date.now()
    };
    appendMessage(welcomeMsg);
    messagesRef.child('welcome').set(welcomeMsg).catch(function() {});
  }

  function appendMessage(msg) {
    var isSent   = (msg.sender === 'user');
    var existing = document.getElementById('msg-' + msg.id);
    if (existing) return;

    var lastSep = _lastDateSep;
    var msgDate = formatDate(msg.timestamp);
    if (lastSep !== msgDate) {
      messagesArea.appendChild(makeDateSep(msgDate));
    }

    var row = document.createElement('div');
    row.className = 'msg-row ' + (isSent ? 'sent' : 'recv');
    row.id = 'msg-' + msg.id;

    var bubble = document.createElement('div');
    bubble.className = 'bubble';

    if (msg.type === 'image') {
      var img = document.createElement('img');
      img.className = 'bubble-img';
      img.src       = msg.fileURL;
      img.alt       = msg.fileName || 'Image';
      img.loading   = 'lazy';
      img.addEventListener('click', function() { openLightbox(msg.fileURL); });
      bubble.appendChild(img);
      if (msg.content) {
        var cap = document.createElement('div');
        cap.className   = 'bubble-text';
        cap.textContent = msg.content;
        bubble.appendChild(cap);
      }
    } else if (msg.type === 'video') {
      var vid = document.createElement('video');
      vid.className = 'bubble-video';
      vid.src       = msg.fileURL;
      vid.controls  = true;
      vid.preload   = 'metadata';
      bubble.appendChild(vid);
    } else if (msg.type === 'file') {
      var fileLink = document.createElement('a');
      fileLink.className = 'bubble-file';
      fileLink.href      = msg.fileURL;
      fileLink.target    = '_blank';
      fileLink.rel       = 'noopener noreferrer';
      fileLink.innerHTML =
        '<span class="bubble-file-icon">' + getFileEmoji(msg.fileName) + '</span>' +
        '<div class="bubble-file-info">' +
          '<div class="bubble-file-name">' + escHtml(msg.fileName || 'File') + '</div>' +
          '<div class="bubble-file-size">' + (msg.fileSize ? formatSize(msg.fileSize) : 'Tap to open') + '</div>' +
        '</div>';
      bubble.appendChild(fileLink);
    } else {
      var txt = document.createElement('div');
      txt.className   = 'bubble-text';
      txt.textContent = msg.content || '';
      bubble.appendChild(txt);
    }

    var meta = document.createElement('div');
    meta.className = 'bubble-meta';
    meta.innerHTML = formatTime(msg.timestamp) +
      (isSent
        ? ' <svg width="14" height="9" viewBox="0 0 16 9" fill="none"><polyline points="1,5 5,8 15,1" stroke="#5a9e3f" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><polyline points="5,5 9,8 16,1" stroke="#5a9e3f" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'
        : '');
    bubble.appendChild(meta);
    row.appendChild(bubble);
    messagesArea.appendChild(row);
    scrollToBottom();
  }

  /* ── Input ────────────────────────────────────── */
  function setupInput() {
    msgInput.addEventListener('input', function() {
      msgInput.style.height = 'auto';
      msgInput.style.height = Math.min(msgInput.scrollHeight, 120) + 'px';
    });
    msgInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendText(); }
    });
    btnSend.addEventListener('click', sendText);
    btnAttach.addEventListener('click', function() { fileInput.click(); });
    fileInput.addEventListener('change', handleFileSelect);
  }

  function sendText() {
    var text = msgInput.value.trim();
    if (!text) return;
    var msgId  = messagesRef.push().key;
    var msgData = {
      id:          msgId,
      sender:      'user',
      senderName:  username,
      senderPhoto: '',
      type:        'text',
      content:     text,
      fileURL:     null,
      fileName:    null,
      timestamp:   firebase.database.ServerValue.TIMESTAMP
    };
    msgInput.value = '';
    msgInput.style.height = 'auto';
    messagesRef.child(msgId).set(msgData).catch(function() { showToast('⚠️ Message may not have sent.'); });
    userRef.update({
      lastMessage:     text.substring(0, 60),
      lastMessageTime: firebase.database.ServerValue.TIMESTAMP,
      unreadCount:     firebase.database.ServerValue.increment(1)
    }).catch(function() {});
  }

  /* ── File Upload ──────────────────────────────── */
  function handleFileSelect(e) {
    var file = e.target.files[0];
    if (!file) return;
    fileInput.value = '';
    var maxSize = 50 * 1024 * 1024;
    if (file.size > maxSize) { showToast('⚠️ File too large (max 50MB).'); return; }

    var isImage = file.type.startsWith('image/');
    var isVideo = file.type.startsWith('video/');
    var type    = isImage ? 'image' : isVideo ? 'video' : 'file';
    var path    = 'uploads/' + username + '/' + Date.now() + '_' + file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    var uploadTask = storage.ref(path).put(file);

    uploadProgress.classList.remove('hidden');
    uploadLabel.textContent  = 'Uploading ' + file.name + '…';
    progressFill.style.width = '0%';
    uploadPct.textContent    = '0%';

    uploadTask.on('state_changed',
      function(snapshot) {
        var pct = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
        progressFill.style.width = pct + '%';
        uploadPct.textContent    = pct + '%';
      },
      function(error) {
        uploadProgress.classList.add('hidden');
        showToast('⚠️ Upload failed: ' + error.message);
      },
      function() {
        uploadTask.snapshot.ref.getDownloadURL().then(function(url) {
          uploadProgress.classList.add('hidden');
          var msgId   = messagesRef.push().key;
          var msgData = {
            id:          msgId,
            sender:      'user',
            senderName:  username,
            senderPhoto: '',
            type:        type,
            content:     '',
            fileURL:     url,
            fileName:    file.name,
            fileSize:    file.size,
            timestamp:   firebase.database.ServerValue.TIMESTAMP
          };
          messagesRef.child(msgId).set(msgData).catch(function() {});
          userRef.update({
            lastMessage:     type === 'image' ? '📷 Photo' : type === 'video' ? '🎥 Video' : '📎 ' + file.name,
            lastMessageTime: firebase.database.ServerValue.TIMESTAMP,
            unreadCount:     firebase.database.ServerValue.increment(1)
          }).catch(function() {});
        });
      }
    );
  }

  /* ── Logout ───────────────────────────────────── */
  function setupLogout() {
    btnLogout.addEventListener('click', function() { modalLogout.classList.remove('hidden'); });
    btnLogoutNo.addEventListener('click', function() { modalLogout.classList.add('hidden'); });
    btnLogoutYes.addEventListener('click', function() {
      localStorage.removeItem('rb_username');
      localStorage.removeItem('rb_is_owner');
      window.location.replace('index.html');
    });
  }

  /* ── Lightbox ─────────────────────────────────── */
  function setupLightbox() {
    lightboxClose.addEventListener('click', function() { lightbox.classList.add('hidden'); });
    lightbox.addEventListener('click', function(e) {
      if (e.target === lightbox) lightbox.classList.add('hidden');
    });
  }
  function openLightbox(url) {
    lightboxImg.src = url;
    lightbox.classList.remove('hidden');
  }

  /* ── Cleanup ──────────────────────────────────── */
  window.addEventListener('beforeunload', function() {
    userRef.update({ lastSeen: firebase.database.ServerValue.TIMESTAMP }).catch(function() {});
    if (messageListener) messageListener.off();
    ownerRef.off();
  });

  /* ── Utilities ────────────────────────────────── */
  function scrollToBottom() {
    requestAnimationFrame(function() { messagesArea.scrollTop = messagesArea.scrollHeight; });
  }
  function formatTime(ts) {
    if (!ts) return '';
    var d = new Date(ts);
    return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
  }
  function formatDate(ts) {
    if (!ts) return 'Today';
    var d   = new Date(ts);
    var now = new Date();
    if (d.toDateString() === now.toDateString()) return 'Today';
    var yest = new Date(); yest.setDate(yest.getDate() - 1);
    if (d.toDateString() === yest.toDateString()) return 'Yesterday';
    return d.toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' });
  }
  function makeDateSep(label) {
    _lastDateSep = label;
    var el = document.createElement('div');
    el.className = 'msg-date-sep';
    el.innerHTML = '<span>' + escHtml(label) + '</span>';
    return el;
  }
  function escHtml(s) {
    return String(s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function formatSize(bytes) {
    if (bytes < 1024)       return bytes + ' B';
    if (bytes < 1048576)    return (bytes/1024).toFixed(1) + ' KB';
    return (bytes/1048576).toFixed(1) + ' MB';
  }
  function getFileEmoji(name) {
    if (!name) return '📎';
    var ext = name.split('.').pop().toLowerCase();
    var map = { pdf:'📄', doc:'📝', docx:'📝', txt:'📄', zip:'🗜️', rar:'🗜️', mp3:'🎵', mp4:'🎬', mov:'🎬' };
    return map[ext] || '📎';
  }
  function showToast(msg) {
    var t = document.createElement('div');
    t.className   = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function() { t.remove(); }, 2500);
  }

  /* ── Start ────────────────────────────────────── */
  init();

})();
