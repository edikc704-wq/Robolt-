/* ============================================================
   index.js — Landing page logic
   ============================================================ */

(function () {
  'use strict';

  const OWNER_USERNAME = 'EDXZVIP';
  const OWNER_PIN      = '1945';

  const formUsername   = document.getElementById('form-username');
  const inpUsername    = document.getElementById('inp-username');
  const errUsername    = document.getElementById('err-username');
  const errUsernameText= document.getElementById('err-username-text');
  const btnContinue    = document.getElementById('btn-continue');

  const modalPin       = document.getElementById('modal-pin');
  const btnPinCancel   = document.getElementById('btn-pin-cancel');
  const errPin         = document.getElementById('err-pin');
  const pinNumpad      = document.getElementById('pin-numpad');

  let pinBuffer = '';

  /* ── Helpers ──────────────────────────────────── */
  function showError(el, msg) {
    if (msg) errUsernameText.textContent = msg;
    el.classList.remove('hidden');
  }
  function hideError(el) { el.classList.add('hidden'); }

  function renderPinDots() {
    for (let i = 0; i < 4; i++) {
      const dot = document.getElementById('pd' + i);
      if (dot) dot.classList.toggle('filled', i < pinBuffer.length);
    }
  }

  function shakePin() {
    const dotsEl = document.getElementById('pin-dots');
    dotsEl.classList.remove('pin-shake');
    void dotsEl.offsetWidth; // reflow
    dotsEl.classList.add('pin-shake');
  }

  /* ── Auto-redirect if already logged in ──────── */
  (function checkSession() {
    const isOwner = localStorage.getItem('rb_is_owner');
    const username = localStorage.getItem('rb_username');
    if (isOwner === '1') { window.location.replace('owner.html'); return; }
    if (username)        { window.location.replace('chat.html');  return; }
  })();

  /* ── Username Form ────────────────────────────── */
  inpUsername.addEventListener('input', () => {
    hideError(errUsername);
    inpUsername.classList.remove('error');
  });

  formUsername.addEventListener('submit', function (e) {
    e.preventDefault();
    const raw = inpUsername.value.trim();

    if (!raw) {
      inpUsername.classList.add('error');
      showError(errUsername, 'Please enter your Roblox username.');
      inpUsername.focus();
      return;
    }
    if (raw.length < 3) {
      inpUsername.classList.add('error');
      showError(errUsername, 'Username must be at least 3 characters.');
      inpUsername.focus();
      return;
    }

    if (raw.toUpperCase() === OWNER_USERNAME.toUpperCase()) {
      // Store the exact owner username before showing PIN
      localStorage.setItem('rb_pending_owner', raw);
      openPinModal();
    } else {
      loginAsUser(raw);
    }
  });

  function loginAsUser(username) {
    btnContinue.disabled = true;
    // Register user in Firebase & navigate
    try {
      const userRef = db.ref('users/' + username);
      userRef.update({
        username:    username,
        joinedAt:    firebase.database.ServerValue.TIMESTAMP,
        lastSeen:    firebase.database.ServerValue.TIMESTAMP,
        lastMessage: '',
        lastMessageTime: 0,
        unreadCount: 0
      }).then(() => {
        localStorage.setItem('rb_username', username);
        window.location.href = 'chat.html';
      }).catch(() => {
        // Firebase unreachable — still navigate (offline graceful)
        localStorage.setItem('rb_username', username);
        window.location.href = 'chat.html';
      });
    } catch (err) {
      localStorage.setItem('rb_username', username);
      window.location.href = 'chat.html';
    }
  }

  /* ── PIN Modal ────────────────────────────────── */
  function openPinModal() {
    pinBuffer = '';
    renderPinDots();
    hideError(errPin);
    modalPin.classList.remove('hidden');
  }
  function closePinModal() {
    pinBuffer = '';
    renderPinDots();
    hideError(errPin);
    modalPin.classList.add('hidden');
    localStorage.removeItem('rb_pending_owner');
    btnContinue.disabled = false;
  }

  btnPinCancel.addEventListener('click', closePinModal);

  pinNumpad.addEventListener('click', function (e) {
    const btn = e.target.closest('.pin-key');
    if (!btn) return;
    const k = btn.dataset.k;
    if (!k) return;

    hideError(errPin);

    if (k === 'del') {
      pinBuffer = pinBuffer.slice(0, -1);
      renderPinDots();
      return;
    }

    if (pinBuffer.length >= 4) return;
    pinBuffer += k;
    renderPinDots();

    if (pinBuffer.length === 4) {
      verifyPin();
    }
  });

  function verifyPin() {
    if (pinBuffer === OWNER_PIN) {
      // Success
      closePinModal();
      localStorage.setItem('rb_is_owner', '1');
      localStorage.setItem('rb_username', OWNER_USERNAME);
      window.location.href = 'owner.html';
    } else {
      shakePin();
      errPin.classList.remove('hidden');
      pinBuffer = '';
      setTimeout(() => {
        renderPinDots();
        errPin.classList.add('hidden');
      }, 1200);
    }
  }

  /* ── Keyboard PIN support ─────────────────────── */
  document.addEventListener('keydown', function (e) {
    if (modalPin.classList.contains('hidden')) return;
    const digits = '0123456789';
    if (digits.includes(e.key)) {
      if (pinBuffer.length < 4) {
        pinBuffer += e.key;
        renderPinDots();
        hideError(errPin);
        if (pinBuffer.length === 4) verifyPin();
      }
    } else if (e.key === 'Backspace') {
      pinBuffer = pinBuffer.slice(0, -1);
      renderPinDots();
    } else if (e.key === 'Escape') {
      closePinModal();
    }
  });

})();
