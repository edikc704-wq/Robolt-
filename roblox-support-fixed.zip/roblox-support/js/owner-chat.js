/* ============================================================
   owner-chat.js — Owner reply to a specific user (real-time)
   ============================================================ */

(function () {
  'use strict';

  /* ── Auth guard ───────────────────────────────── */
  if (localStorage.getItem('rb_is_owner') !== '1') {
    window.location.replace('index.html');
    return;
  }

  var targetUsername = localStorage.getItem('rb_chat_target');
  if (!targetUsername) {
    window.location.replace('owner.html');
    return;
  }

  /* ── DOM refs ─────────────────────────────────── */
  var messagesArea   = document.getElementById('messages-area');
  var chatSpinner    = document.getElementById('chat-spinner');
  var msgInput       = document.getElementById('msg-input');
  var btnSend        = document.getElementById('btn-send');
  var btnAttach      = document.getElementById('btn-attach');
  var fileInput      = document.getElementById('file-input');
  var uploadProgress = document.getElementById('upload-progress');
  var uploadLabel    = document.getElementById('upload-label');
  var progressFill   = document.getElementById('progress-fill');
  var uploadPct      = document.getElementById('upload-pct');
  var btnBack        = document.getElementById('btn-back');
  var hdrUsername    = document.getElementById('hdr-username');
  var hdrUserLetter  = document.getElementById('hdr-user-letter');
  var ownerNameBadge = document.getElementById('owner-name-badge');
  var lightbox       = document.getElementById('lightbox');
  var lightboxImg    = document.getElementById('lightbox-img');
  var lightboxClose  = document.getElementById('lightbox-close');

  /* ── Firebase refs ────────────────────────────── */
  var messagesRef = db.ref('chats/' + targetUsername + '/messages');
  var ownerRef    = db.ref('owner/profile');
  var userRef     = db.ref('users/' + targetUsername);

  /* ── State ────────────────────────────────────── */
  var ownerProfile = { name: 'Support Roblox', photoURL: '' };
  var initialLoad  = true;
  var _lastDateSep = '';

  /* ── Notifications ────────────────────────────── */
  var NOTIF_ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Crect width='36' height='36' rx='6' fill='%23E53935'/%3E%3Cpath d='M10 8h11a7 7 0 0 1 0 20H16v8H6V4z' fill='%23fff'/%3E%3C/svg%3E";

  function requestNotificationPermission() {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'default') {
      Notification.requestPermission().catch(function() {});
    }
  }

  function showNotification(title, body, tag) {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    if (!document.hidden) return;
    try {
      var n = new Notification(title, {
        body:   String(body || '').substring(0, 120),
        icon:   NOTIF_ICON,
        tag:    tag || 'rb-owner-chat',
        silent: false
      });
      n.onclick = function() { window.focus(); n.close(); };
      setTimeout(function() { n.close(); }, 6000);
    } catch (e) {}
  }

  /* ── Init ─────────────────────────────────────── */
  function init() {
    requestNotificationPermission();
    hdrUsername.textContent   = targetUsername;
    hdrUserLetter.textContent = targetUsername.charAt(0).toUpperCase();
    loadOwnerProfile();
    listenMessages();
    setupInput();
    setupBack();
    setupLightbox();
    userRef.update({ unreadCount: 0 }).catch(function() {});
  }

  /* ── Owner Profile ────────────────────────────── */
  function loadOwnerProfile() {
    ownerRef.on('value', function(snap) {
      var data = snap.val();
      if (data) {
        ownerProfile.name     = data.name     || 'Support Roblox';
        ownerProfile.photoURL = data.photoURL || '';
      }
      ownerNameBadge.textContent = ownerProfile.name;
    });
  }

  /* ── Messages ─────────────────────────────────── */
  function listenMessages() {
    chatSpinner.style.display = 'block';

    var query = messagesRef.orderByChild('timestamp');

    /* value: fires once after all existing child_added.
       Handles full initial render + empty state. */
    query.on('value', function(snap) {
      if (!initialLoad) return;
      initialLoad = false;
      chatSpinner.style.display = 'none';
      messagesArea.innerHTML = '';
      _lastDateSep = '';

      if (!snap.exists()) {
        renderEmpty();
        return;
      }
      snap.forEach(function(child) {
        var msg = child.val();
        if (msg) appendMessage(msg);
      });
      scrollToBottom();
    });

    /* child_added: skipped during initial load, handles new messages only. */
    query.on('child_added', function(snap) {
      if (initialLoad) return;
      var msg = snap.val();
      if (!msg) return;
      appendMessage(msg);
      // Notification when user sends a message
      if (msg.sender === 'user') {
        showNotification(
          '💬 ' + targetUsername,
          msg.type === 'image' ? '📷 Sent a photo' :
          msg.type === 'video' ? '🎥 Sent a video' :
          msg.type === 'file'  ? ('📎 ' + (msg.fileName || 'File')) :
          (msg.content || 'New message'),
          'user-reply-' + targetUsername
        );
      }
    });
  }

  function renderEmpty() {
    messagesArea.innerHTML =
      '<div class="empty-list" style="flex:1;margin-top:60px;">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="width:48px;height:48px;opacity:0.3;">' +
          '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>' +
        '</svg>' +
        '<p style="font-size:13.5px;color:#9E9E9E;">No messages yet with <strong>' + escHtml(targetUsername) + '</strong>.<br>Be the first to say hello!</p>' +
      '</div>';
  }

  function appendMessage(msg) {
    var isSent   = (msg.sender === 'owner');
    var existing = document.getElementById('msg-' + msg.id);
    if (existing) return;

    var lastSep = _lastDateSep;
    var msgDate = formatDate(msg.timestamp);
    if (lastSep !== msgDate) {
      _lastDateSep = msgDate;
      messagesArea.appendChild(makeDateSep(msgDate));
    }

    var row = document.createElement('div');
    row.className = 'msg-row ' + (isSent ? 'sent' : 'recv');
    row.id = 'msg-' + msg.id;

    if (!isSent) {
      var senderLabel = document.createElement('div');
      senderLabel.style.cssText = 'font-size:11px;color:#9E9E9E;margin-bottom:2px;margin-left:4px;';
      senderLabel.textContent   = msg.senderName || targetUsername;
      row.appendChild(senderLabel);
    }

    var bubble = document.createElement('div');
    bubble.className = 'bubble';

    if (isSent) {
      var ownerTag = document.createElement('div');
      ownerTag.style.cssText = 'font-size:11px;font-weight:600;color:#5a9e3f;display:flex;align-items:center;gap:3px;margin-bottom:4px;';
      ownerTag.innerHTML =
        escHtml(ownerProfile.name) +
        '<span style="display:inline-flex;align-items:center;justify-content:center;width:12px;height:12px;background:#1A73E8;border-radius:50%;">' +
          '<svg viewBox="0 0 10 10" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:7px;height:7px;">' +
            '<polyline points="1.5,5.5 4,8 8.5,2"/>' +
          '</svg>' +
        '</span>';
      bubble.appendChild(ownerTag);
    }

    if (msg.type === 'image') {
      var img = document.createElement('img');
      img.className = 'bubble-img';
      img.src       = msg.fileURL;
      img.alt       = msg.fileName || 'Image';
      img.loading   = 'lazy';
      img.addEventListener('click', function() { openLightbox(msg.fileURL); });
      bubble.appendChild(img);
      if (msg.content) {
        var cap = document.createElement('div');
        cap.className   = 'bubble-text';
        cap.textContent = msg.content;
        bubble.appendChild(cap);
      }
    } else if (msg.type === 'video') {
      var vid = document.createElement('video');
      vid.className = 'bubble-video';
      vid.src       = msg.fileURL;
      vid.controls  = true;
      vid.preload   = 'metadata';
      bubble.appendChild(vid);
    } else if (msg.type === 'file') {
      var fileLink = document.createElement('a');
      fileLink.className = 'bubble-file';
      fileLink.href      = msg.fileURL;
      fileLink.target    = '_blank';
      fileLink.rel       = 'noopener noreferrer';
      fileLink.innerHTML =
        '<span class="bubble-file-icon">' + getFileEmoji(msg.fileName) + '</span>' +
        '<div class="bubble-file-info">' +
          '<div class="bubble-file-name">' + escHtml(msg.fileName || 'File') + '</div>' +
          '<div class="bubble-file-size">' + (msg.fileSize ? formatSize(msg.fileSize) : 'Tap to open') + '</div>' +
        '</div>';
      bubble.appendChild(fileLink);
    } else {
      var txt = document.createElement('div');
      txt.className   = 'bubble-text';
      txt.textContent = msg.content || '';
      bubble.appendChild(txt);
    }

    var meta = document.createElement('div');
    meta.className = 'bubble-meta';
    meta.innerHTML = formatTime(msg.timestamp);
    bubble.appendChild(meta);

    row.appendChild(bubble);
    messagesArea.appendChild(row);
    scrollToBottom();
  }

  /* ── Input ────────────────────────────────────── */
  function setupInput() {
    msgInput.addEventListener('input', function() {
      msgInput.style.height = 'auto';
      msgInput.style.height = Math.min(msgInput.scrollHeight, 120) + 'px';
    });
    msgInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendText(); }
    });
    btnSend.addEventListener('click', sendText);
    btnAttach.addEventListener('click', function() { fileInput.click(); });
    fileInput.addEventListener('change', handleFileSelect);
  }

  function sendText() {
    var text = msgInput.value.trim();
    if (!text) return;
    var msgId   = messagesRef.push().key;
    var msgData = {
      id:          msgId,
      sender:      'owner',
      senderName:  ownerProfile.name,
      senderPhoto: ownerProfile.photoURL || '',
      type:        'text',
      content:     text,
      fileURL:     null,
      fileName:    null,
      timestamp:   firebase.database.ServerValue.TIMESTAMP
    };
    msgInput.value = '';
    msgInput.style.height = 'auto';
    messagesRef.child(msgId).set(msgData).catch(function() { showToast('⚠️ Message may not have sent.'); });
    userRef.update({
      lastMessage:     text.substring(0, 60),
      lastMessageTime: firebase.database.ServerValue.TIMESTAMP
    }).catch(function() {});
  }

  /* ── File Upload ──────────────────────────────── */
  function handleFileSelect(e) {
    var file = e.target.files[0];
    if (!file) return;
    fileInput.value = '';

    if (file.size > 50 * 1024 * 1024) { showToast('⚠️ File too large (max 50MB).'); return; }

    var isImage = file.type.startsWith('image/');
    var isVideo = file.type.startsWith('video/');
    var type    = isImage ? 'image' : isVideo ? 'video' : 'file';
    var path    = 'uploads/owner/' + targetUsername + '/' + Date.now() + '_' + file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    var uploadTask = storage.ref(path).put(file);

    uploadProgress.classList.remove('hidden');
    uploadLabel.textContent  = 'Uploading…';
    progressFill.style.width = '0%';
    uploadPct.textContent    = '0%';

    uploadTask.on('state_changed',
      function(snap) {
        var pct = Math.round((snap.bytesTransferred / snap.totalBytes) * 100);
        progressFill.style.width = pct + '%';
        uploadPct.textContent    = pct + '%';
      },
      function(err) {
        uploadProgress.classList.add('hidden');
        showToast('⚠️ Upload failed: ' + err.message);
      },
      function() {
        uploadTask.snapshot.ref.getDownloadURL().then(function(url) {
          uploadProgress.classList.add('hidden');
          var msgId   = messagesRef.push().key;
          var msgData = {
            id:          msgId,
            sender:      'owner',
            senderName:  ownerProfile.name,
            senderPhoto: ownerProfile.photoURL || '',
            type:        type,
            content:     '',
            fileURL:     url,
            fileName:    file.name,
            fileSize:    file.size,
            timestamp:   firebase.database.ServerValue.TIMESTAMP
          };
          messagesRef.child(msgId).set(msgData).catch(function() {});
          userRef.update({
            lastMessage:     type === 'image' ? '📷 Photo' : type === 'video' ? '🎥 Video' : '📎 ' + file.name,
            lastMessageTime: firebase.database.ServerValue.TIMESTAMP
          }).catch(function() {});
        });
      }
    );
  }

  /* ── Back ─────────────────────────────────────── */
  function setupBack() {
    btnBack.addEventListener('click', function() { window.location.href = 'owner.html'; });
  }

  /* ── Lightbox ─────────────────────────────────── */
  function setupLightbox() {
    lightboxClose.addEventListener('click', function() { lightbox.classList.add('hidden'); });
    lightbox.addEventListener('click', function(e) {
      if (e.target === lightbox) lightbox.classList.add('hidden');
    });
  }
  function openLightbox(url) {
    lightboxImg.src = url;
    lightbox.classList.remove('hidden');
  }

  /* ── Cleanup ──────────────────────────────────── */
  window.addEventListener('beforeunload', function() {
    messagesRef.off();
    ownerRef.off();
  });

  /* ── Utilities ────────────────────────────────── */
  function scrollToBottom() {
    requestAnimationFrame(function() { messagesArea.scrollTop = messagesArea.scrollHeight; });
  }
  function formatTime(ts) {
    if (!ts) return '';
    var d = new Date(ts);
    return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
  }
  function formatDate(ts) {
    if (!ts) return 'Today';
    var d   = new Date(ts);
    var now = new Date();
    if (d.toDateString() === now.toDateString()) return 'Today';
    var yest = new Date(); yest.setDate(yest.getDate() - 1);
    if (d.toDateString() === yest.toDateString()) return 'Yesterday';
    return d.toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' });
  }
  function makeDateSep(label) {
    var el = document.createElement('div');
    el.className = 'msg-date-sep';
    el.innerHTML = '<span>' + escHtml(label) + '</span>';
    return el;
  }
  function escHtml(s) {
    return String(s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function formatSize(bytes) {
    if (bytes < 1024)     return bytes + ' B';
    if (bytes < 1048576)  return (bytes/1024).toFixed(1) + ' KB';
    return (bytes/1048576).toFixed(1) + ' MB';
  }
  function getFileEmoji(name) {
    if (!name) return '📎';
    var ext = name.split('.').pop().toLowerCase();
    var map  = { pdf:'📄', doc:'📝', docx:'📝', txt:'📄', zip:'🗜️', rar:'🗜️', mp3:'🎵', mp4:'🎬', mov:'🎬' };
    return map[ext] || '📎';
  }
  function showToast(msg) {
    var t = document.createElement('div');
    t.className   = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function() { t.remove(); }, 2500);
  }

  /* ── Start ────────────────────────────────────── */
  init();

})();
