// ============================================================
//  FIREBASE CONFIGURATION — edxzvip-76
//  Project: edxzvip-76 | Region: default (US)
//  NOTE: Pastikan Realtime Database sudah aktif di Firebase Console
//        dengan URL: https://edxzvip-76-default-rtdb.firebaseio.com
// ============================================================

const firebaseConfig = {
  apiKey:            "AIzaSyDHh09X8EeK-8isvW6IbbfgMY5AWltQiug",
  authDomain:        "edxzvip-76.firebaseapp.com",
  databaseURL:       "https://edxzvip-76-default-rtdb.firebaseio.com",
  projectId:         "edxzvip-76",
  storageBucket:     "edxzvip-76.firebasestorage.app",
  messagingSenderId: "135111263510",
  appId:             "1:135111263510:web:6f7e3287df02b00999fc37",
  measurementId:     "G-DGYQVQ83NB"
};

firebase.initializeApp(firebaseConfig);
const db      = firebase.database();
const storage = firebase.storage();
