/* ============================================================
   owner.js — Owner dashboard logic (real-time via Firebase)
   ============================================================ */

(function () {
  'use strict';

  /* ── Auth guard ───────────────────────────────── */
  if (localStorage.getItem('rb_is_owner') !== '1') {
    window.location.replace('index.html');
    return;
  }

  /* ── DOM refs ─────────────────────────────────── */
  var viewHome          = document.getElementById('view-home');
  var viewSettings      = document.getElementById('view-settings');
  var userList          = document.getElementById('user-list');
  var listSpinner       = document.getElementById('list-spinner');
  var navHome           = document.getElementById('nav-home');
  var navSettings       = document.getElementById('nav-settings');
  var tabLabel          = document.getElementById('tab-label');

  var hdrName           = document.getElementById('hdr-name');
  var hdrAvatarLetter   = document.getElementById('hdr-avatar-letter');
  var hdrAvatar         = document.getElementById('hdr-avatar');

  var btnLogout         = document.getElementById('btn-logout');
  var modalLogout       = document.getElementById('modal-logout');
  var btnLogoutNo       = document.getElementById('btn-logout-no');
  var btnLogoutYes      = document.getElementById('btn-logout-yes');

  var avatarWrap        = document.getElementById('avatar-wrap');
  var avatarFileInput   = document.getElementById('avatar-file-input');
  var settingsAvatar    = document.getElementById('settings-avatar');
  var settingsAvatarLetter = document.getElementById('settings-avatar-letter');
  var profileNameInput  = document.getElementById('profile-name-input');
  var btnSaveProfile    = document.getElementById('btn-save-profile');

  var clearUsernameInput = document.getElementById('clear-username-input');
  var btnClearChat       = document.getElementById('btn-clear-chat');
  var modalClear         = document.getElementById('modal-clear');
  var clearConfirmUser   = document.getElementById('clear-confirm-username');
  var btnClearNo         = document.getElementById('btn-clear-no');
  var btnClearYes        = document.getElementById('btn-clear-yes');

  /* ── Firebase refs ────────────────────────────── */
  var ownerRef = db.ref('owner/profile');
  var usersRef = db.ref('users');

  /* ── State ────────────────────────────────────── */
  var ownerProfile         = { name: 'Support Roblox', photoURL: '' };
  var userMap              = {};
  var pendingClearUsername = '';
  var prevUnreadMap        = {};
  var notifReady           = false;

  /* ── Notifications ────────────────────────────── */
  var NOTIF_ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'%3E%3Crect width='36' height='36' rx='6' fill='%23E53935'/%3E%3Cpath d='M10 8h11a7 7 0 0 1 0 20H16v8H6V4z' fill='%23fff'/%3E%3C/svg%3E";

  function requestNotificationPermission() {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'default') {
      Notification.requestPermission().catch(function() {});
    }
  }

  function showNotification(title, body, tag) {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    if (!document.hidden) return;
    try {
      var n = new Notification(title, {
        body:   String(body || '').substring(0, 120),
        icon:   NOTIF_ICON,
        tag:    tag || 'rb-owner',
        silent: false
      });
      n.onclick = function() { window.focus(); n.close(); };
      setTimeout(function() { n.close(); }, 6000);
    } catch (e) {}
  }

  /* ── Init ─────────────────────────────────────── */
  function init() {
    requestNotificationPermission();
    setupNavigation();
    loadOwnerProfile();
    listenUsers();
    setupLogout();
    setupSettings();
  }

  /* ── Navigation ───────────────────────────────── */
  function setupNavigation() {
    navHome.addEventListener('click', function() { showView('home'); });
    navSettings.addEventListener('click', function() { showView('settings'); });
  }

  function showView(view) {
    if (view === 'home') {
      viewHome.classList.remove('hidden');
      viewSettings.classList.add('hidden');
      navHome.classList.add('active');
      navSettings.classList.remove('active');
      tabLabel.textContent = 'Inbox';
    } else {
      viewHome.classList.add('hidden');
      viewSettings.classList.remove('hidden');
      navHome.classList.remove('active');
      navSettings.classList.add('active');
      tabLabel.textContent = 'Settings';
    }
  }

  /* ── Owner Profile ────────────────────────────── */
  function loadOwnerProfile() {
    ownerRef.on('value', function(snap) {
      var data = snap.val();
      if (data) {
        ownerProfile.name     = data.name     || 'Support Roblox';
        ownerProfile.photoURL = data.photoURL || '';
      }
      applyOwnerProfile();
    });
  }

  function applyOwnerProfile() {
    hdrName.textContent   = ownerProfile.name;
    profileNameInput.value = ownerProfile.name;
    var letter = ownerProfile.name.charAt(0).toUpperCase() || 'S';
    hdrAvatarLetter.textContent      = letter;
    settingsAvatarLetter.textContent = letter;

    if (ownerProfile.photoURL) {
      hdrAvatar.innerHTML      = '<img src="' + ownerProfile.photoURL + '" alt="Owner" style="width:100%;height:100%;object-fit:cover;" />';
      settingsAvatar.innerHTML = '<img src="' + ownerProfile.photoURL + '" alt="Owner" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />';
    } else {
      hdrAvatar.innerHTML      = '<span id="hdr-avatar-letter" style="font-size:18px;font-weight:700;color:#E53935;">' + letter + '</span>';
      settingsAvatar.innerHTML = '<span id="settings-avatar-letter" style="font-size:28px;font-weight:700;color:#fff;">' + letter + '</span>';
    }
  }

  /* ── User List ────────────────────────────────── */
  function listenUsers() {
    usersRef.orderByChild('lastMessageTime').on('value', function(snap) {
      listSpinner.style.display = 'none';
      userMap = {};
      var users = [];

      snap.forEach(function(child) {
        var u = child.val();
        if (u && u.username) {
          userMap[u.username] = u;
          if (u.lastMessageTime && u.lastMessageTime > 0) {
            users.push(u);
          }
        }
      });

      /* ── Notification: new messages from users ── */
      if (notifReady) {
        users.forEach(function(u) {
          var prev = prevUnreadMap[u.username] || 0;
          var curr = u.unreadCount || 0;
          if (curr > prev) {
            showNotification(
              '💬 ' + u.username,
              u.lastMessage || 'Sent a message',
              'user-msg-' + u.username
            );
          }
        });
      }

      /* Update prev unread map */
      users.forEach(function(u) {
        prevUnreadMap[u.username] = u.unreadCount || 0;
      });
      notifReady = true;

      /* Sort descending by lastMessageTime */
      users.sort(function(a, b) { return (b.lastMessageTime || 0) - (a.lastMessageTime || 0); });
      renderUserList(users);
    });
  }

  function renderUserList(users) {
    userList.innerHTML = '';

    if (users.length === 0) {
      userList.innerHTML =
        '<div class="empty-list">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>' +
          '</svg>' +
          '<p>No user messages yet.<br>Waiting for users to start a chat.</p>' +
        '</div>';
      return;
    }

    users.forEach(function(u) {
      var row = document.createElement('div');
      row.className = 'user-row';
      row.dataset.username = u.username;

      var letter  = u.username.charAt(0).toUpperCase();
      var unread  = u.unreadCount || 0;
      var lastMsg = u.lastMessage
        ? escHtml(u.lastMessage.substring(0, 60))
        : '<i style="color:#bbb;">No messages</i>';
      var timeStr = u.lastMessageTime ? relativeTime(u.lastMessageTime) : '';

      row.innerHTML =
        '<div class="user-avatar" style="background:' + avatarColor(u.username) + ';">' + letter + '</div>' +
        '<div class="user-info">' +
          '<div class="user-name-row">' +
            '<div class="user-name">' + escHtml(u.username) + '</div>' +
            '<div class="user-time">' + timeStr + '</div>' +
          '</div>' +
          '<div style="display:flex;align-items:center;justify-content:space-between;gap:6px;">' +
            '<div class="user-last-msg">' + lastMsg + '</div>' +
            (unread > 0 ? '<div class="unread-badge">' + (unread > 99 ? '99+' : unread) + '</div>' : '') +
          '</div>' +
        '</div>';

      row.addEventListener('click', function() { openUserChat(u.username); });
      userList.appendChild(row);
    });
  }

  function openUserChat(username) {
    db.ref('users/' + username).update({ unreadCount: 0 }).catch(function() {});
    localStorage.setItem('rb_chat_target', username);
    window.location.href = 'owner-chat.html';
  }

  /* ── Logout ───────────────────────────────────── */
  function setupLogout() {
    btnLogout.addEventListener('click', function() { modalLogout.classList.remove('hidden'); });
    btnLogoutNo.addEventListener('click', function() { modalLogout.classList.add('hidden'); });
    btnLogoutYes.addEventListener('click', function() {
      localStorage.removeItem('rb_username');
      localStorage.removeItem('rb_is_owner');
      localStorage.removeItem('rb_chat_target');
      window.location.replace('index.html');
    });
  }

  /* ── Settings ─────────────────────────────────── */
  function setupSettings() {
    avatarWrap.addEventListener('click', function() { avatarFileInput.click(); });
    avatarFileInput.addEventListener('change', handleAvatarUpload);

    btnSaveProfile.addEventListener('click', saveProfile);
    profileNameInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') { e.preventDefault(); saveProfile(); }
    });

    btnClearChat.addEventListener('click', function() {
      var targetUsername = clearUsernameInput.value.trim();
      if (!targetUsername) { showToast('⚠️ Enter a username first.'); return; }
      pendingClearUsername = targetUsername;
      clearConfirmUser.textContent = targetUsername;
      modalClear.classList.remove('hidden');
    });
    btnClearNo.addEventListener('click', function() {
      modalClear.classList.add('hidden');
      pendingClearUsername = '';
    });
    btnClearYes.addEventListener('click', doClearChat);
  }

  function handleAvatarUpload(e) {
    var file = e.target.files[0];
    if (!file) return;
    avatarFileInput.value = '';

    if (file.size > 5 * 1024 * 1024) { showToast('⚠️ Image too large (max 5MB).'); return; }

    btnSaveProfile.disabled    = true;
    btnSaveProfile.textContent = 'Uploading…';

    var uploadTask = storage.ref('owner/profile-photo').put(file);
    uploadTask.on('state_changed',
      null,
      function(err) {
        showToast('⚠️ Upload failed: ' + err.message);
        btnSaveProfile.disabled    = false;
        btnSaveProfile.textContent = 'Save Profile';
      },
      function() {
        uploadTask.snapshot.ref.getDownloadURL().then(function(url) {
          ownerProfile.photoURL = url;
          ownerRef.update({ photoURL: url }).then(function() {
            showToast('✅ Profile photo updated.');
            applyOwnerProfile();
          }).catch(function() { showToast('⚠️ Could not save photo URL.'); });
          btnSaveProfile.disabled    = false;
          btnSaveProfile.textContent = 'Save Profile';
        });
      }
    );
  }

  function saveProfile() {
    var newName = profileNameInput.value.trim();
    if (!newName) { showToast('⚠️ Name cannot be empty.'); return; }
    btnSaveProfile.disabled    = true;
    btnSaveProfile.textContent = 'Saving…';

    ownerRef.update({ name: newName }).then(function() {
      ownerProfile.name = newName;
      showToast('✅ Profile saved.');
      applyOwnerProfile();
    }).catch(function() {
      showToast('⚠️ Could not save. Check Firebase.');
    }).finally(function() {
      btnSaveProfile.disabled    = false;
      btnSaveProfile.textContent = 'Save Profile';
    });
  }

  function doClearChat() {
    modalClear.classList.add('hidden');
    var target = pendingClearUsername;
    pendingClearUsername = '';
    if (!target) return;
    showToast('🧹 Clearing chat for ' + target + '…');
    db.ref('chats/' + target + '/messages').remove().then(function() {
      return db.ref('users/' + target).update({
        lastMessage: '', lastMessageTime: 0, unreadCount: 0
      });
    }).then(function() {
      showToast('✅ Chat cleared for ' + target + '.');
      clearUsernameInput.value = '';
    }).catch(function(err) {
      showToast('⚠️ Error: ' + err.message);
    });
  }

  /* ── Utilities ────────────────────────────────── */
  function escHtml(s) {
    return String(s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function relativeTime(ts) {
    if (!ts) return '';
    var diff = Date.now() - ts;
    if (diff < 60000)    return 'now';
    if (diff < 3600000)  return Math.floor(diff/60000) + 'm';
    if (diff < 86400000) return Math.floor(diff/3600000) + 'h';
    return new Date(ts).toLocaleDateString('en-US', { month:'short', day:'numeric' });
  }

  var COLORS = ['#E53935','#8E24AA','#1E88E5','#00897B','#F4511E','#6D4C41','#546E7A','#3949AB'];
  function avatarColor(username) {
    var hash = 0;
    for (var i = 0; i < username.length; i++) hash = username.charCodeAt(i) + ((hash << 5) - hash);
    return COLORS[Math.abs(hash) % COLORS.length];
  }

  function showToast(msg) {
    var t = document.createElement('div');
    t.className   = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function() { t.remove(); }, 2500);
  }

  /* ── Start ────────────────────────────────────── */
  init();

})();
